// Esta função recebe valores e devolve um resultado.
function ehPar(a) {
    return a % 2 === 0;
}

// Associar um evento de clique ao botão.
document.getElementById("calcular").addEventListener("click", function() {
    let campo1 = document.getElementById("num1").value;
    let saida = document.getElementById("resultado");

    // Primeiro verificar se os campos foram preenchidos.
    if (campo1.trim() === "") {
        saida.textContent = "Preenche todos os campos!";
        return;
    }

    // Converter os valores introduzidos para números.
    let a = Number(campo1);
    if (!Number.isFinite(a)) {
        saida.textContent = "Introduz números válidos!";
        return;
    }
    if (!Number.isInteger(a)) {
        saida.textContent = "Introduz um número inteiro!";
        return;
    }

    let resposta = (ehPar(a) ? "É par." : "É ímpar.");
    saida.textContent = "Resposta: " + resposta;
});
