// Esta função recebe valores e devolve um resultado.
function maior(a, b) {
    if (a > b) {
        return a;
    } else {
        return b;
    }
}

// Associar um evento de clique ao botão.
document.getElementById("calcular").addEventListener("click", function() {
    let campo1 = document.getElementById("num1").value;
    let campo2 = document.getElementById("num2").value;
    let saida = document.getElementById("resultado");

    // Primeiro verificar se os campos foram preenchidos.
    if (campo1.trim() === "" || campo2.trim() === "") {
        saida.textContent = "Preenche todos os campos!";
        return;
    }

    // Converter os valores introduzidos para números.
    let a = Number(campo1);
    let b = Number(campo2);
    if (!Number.isFinite(a) || !Number.isFinite(b)) {
        saida.textContent = "Introduz números válidos!";
        return;
    }

    let resposta = (a === b ? "Os números são iguais." : maior(a, b));
    saida.textContent = "Maior: " + resposta;
});
