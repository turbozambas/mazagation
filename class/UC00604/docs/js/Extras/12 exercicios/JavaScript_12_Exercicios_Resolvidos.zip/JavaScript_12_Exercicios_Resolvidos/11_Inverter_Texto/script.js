// Função que resolve o exercício.
function inverterTexto(texto) {
    let invertido = "";
    for (let i = texto.length - 1; i >= 0; i--) {
        invertido = invertido + texto[i];
    }
    return invertido;
}

// O código abaixo é executado quando se clica no botão.
document.getElementById("calcular").addEventListener("click", function() {
    let texto = document.getElementById("texto").value;
    let saida = document.getElementById("resultado");

    if (texto.trim() === "") {
        saida.textContent = "O campo não pode estar vazio!";
        return;
    }

    let resposta = inverterTexto(texto);
    saida.textContent = "Invertido: " + resposta;
});
