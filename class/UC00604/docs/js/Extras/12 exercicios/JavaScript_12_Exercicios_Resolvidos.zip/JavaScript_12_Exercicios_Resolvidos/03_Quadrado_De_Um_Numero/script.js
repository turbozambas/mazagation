// Esta função recebe valores e devolve um resultado.
function quadrado(a) {
    return a * a;
}

// Associar um evento de clique ao botão.
document.getElementById("calcular").addEventListener("click", function() {
    let campo1 = document.getElementById("num1").value;
    let saida = document.getElementById("resultado");

    // Primeiro verificar se os campos foram preenchidos.
    if (campo1.trim() === "") {
        saida.textContent = "Preenche todos os campos!";
        return;
    }

    // Converter os valores introduzidos para números.
    let a = Number(campo1);
    if (!Number.isFinite(a)) {
        saida.textContent = "Introduz números válidos!";
        return;
    }

    let resposta = quadrado(a);
    saida.textContent = "Resultado: " + resposta;
});
