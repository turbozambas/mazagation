// Esta função recebe valores e devolve um resultado.
function mediaDeTres(a, b, c) {
    return (a + b + c) / 3;
}

// Associar um evento de clique ao botão.
document.getElementById("calcular").addEventListener("click", function() {
    let campo1 = document.getElementById("num1").value;
    let campo2 = document.getElementById("num2").value;
    let campo3 = document.getElementById("num3").value;
    let saida = document.getElementById("resultado");

    // Primeiro verificar se os campos foram preenchidos.
    if (campo1.trim() === "" || campo2.trim() === "" || campo3.trim() === "") {
        saida.textContent = "Preenche todos os campos!";
        return;
    }

    // Converter os valores introduzidos para números.
    let a = Number(campo1);
    let b = Number(campo2);
    let c = Number(campo3);
    if (!Number.isFinite(a) || !Number.isFinite(b) || !Number.isFinite(c)) {
        saida.textContent = "Introduz números válidos!";
        return;
    }

    let resposta = mediaDeTres(a, b, c);
    saida.textContent = "Média: " + resposta;
});
