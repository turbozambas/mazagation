// Variável que guarda o número de cliques.
let contador = 0;

function incrementar(valor) {
    return valor + 1;
}

function reiniciar() {
    return 0;
}

// Atualizar o texto apresentado no HTML.
function mostrarContador() {
    document.getElementById("resultado").textContent =
        "Total de cliques: " + contador;
}

document.getElementById("clicar").addEventListener("click", function() {
    contador = incrementar(contador);
    mostrarContador();
});

document.getElementById("reiniciar").addEventListener("click", function() {
    contador = reiniciar();
    mostrarContador();
});
