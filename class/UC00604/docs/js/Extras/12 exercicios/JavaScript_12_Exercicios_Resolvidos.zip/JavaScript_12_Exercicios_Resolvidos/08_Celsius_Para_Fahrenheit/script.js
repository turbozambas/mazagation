// Esta função recebe valores e devolve um resultado.
function celsiusParaFahrenheit(a) {
    return a * 9 / 5 + 32;
}

// Associar um evento de clique ao botão.
document.getElementById("calcular").addEventListener("click", function() {
    let campo1 = document.getElementById("num1").value;
    let saida = document.getElementById("resultado");

    // Primeiro verificar se os campos foram preenchidos.
    if (campo1.trim() === "") {
        saida.textContent = "Preenche todos os campos!";
        return;
    }

    // Converter os valores introduzidos para números.
    let a = Number(campo1);
    if (!Number.isFinite(a)) {
        saida.textContent = "Introduz números válidos!";
        return;
    }

    let resposta = celsiusParaFahrenheit(a);
    saida.textContent = "Fahrenheit: " + resposta;
});
