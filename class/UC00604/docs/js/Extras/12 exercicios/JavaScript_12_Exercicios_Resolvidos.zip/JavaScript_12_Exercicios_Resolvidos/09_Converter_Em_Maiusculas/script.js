// Função que resolve o exercício.
function paraMaiusculas(texto) {
    return texto.toUpperCase();
}

// O código abaixo é executado quando se clica no botão.
document.getElementById("calcular").addEventListener("click", function() {
    let texto = document.getElementById("texto").value;
    let saida = document.getElementById("resultado");

    if (texto.trim() === "") {
        saida.textContent = "O campo não pode estar vazio!";
        return;
    }

    let resposta = paraMaiusculas(texto);
    saida.textContent = "Resultado: " + resposta;
});
