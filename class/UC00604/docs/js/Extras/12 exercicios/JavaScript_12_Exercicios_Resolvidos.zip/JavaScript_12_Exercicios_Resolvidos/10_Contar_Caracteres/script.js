// Função que resolve o exercício.
function contarCaracteres(texto) {
    return texto.length;
}

// O código abaixo é executado quando se clica no botão.
document.getElementById("calcular").addEventListener("click", function() {
    let texto = document.getElementById("texto").value;
    let saida = document.getElementById("resultado");

    if (texto.trim() === "") {
        saida.textContent = "O campo não pode estar vazio!";
        return;
    }

    let resposta = contarCaracteres(texto);
    saida.textContent = "Total: " + resposta;
});
